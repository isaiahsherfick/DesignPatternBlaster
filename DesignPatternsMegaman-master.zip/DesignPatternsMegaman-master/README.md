# DesignPatternsMegaman
Group 1's final project in CSCI-P 532 at Indiana University in Fall 2021: Megaman that teaches the player Design Patterns through gameplay.

# Group 1

Isaiah Sherfick,
your name here,
your name here,
your name here,
your name here

# Installation Guide

# Required packages:
Java 8 or higher

# Linux
todo

# Windows
todo

# Macintosh
todo
